import json
from operator import itemgetter


qaC = json.loads(open("Canidates.json", 'r').read())
qaR = json.loads(open("Recruiters.json", "r").read())

def score(currentQuestion, scoreQuestion):

    currentQuestion = currentQuestion.lower()
    scoreQuestion = scoreQuestion.lower()

    cQSplit = currentQuestion.split()
    sQSplit = scoreQuestion.split()


    similarWords = (len([word for word in cQSplit if word in sQSplit]) / len(cQSplit))
    similarWordOrder = 0


    for index, word in enumerate(cQSplit):
        if index == len(sQSplit):
            break
        if word != sQSplit[index]:
            break
        similarWordOrder += 1

    similarWordOrder = similarWordOrder / len(cQSplit)

    similarLetters = 0

    for letter in set(currentQuestion):
        if letter in set(scoreQuestion):
            similarLetters += 1

    wordsINTheWords = 0

    for word in cQSplit:
        if word in scoreQuestion:
            wordsINTheWords += 1

    wordsINTheWords = wordsINTheWords / len(cQSplit)

    similarLetters = similarLetters / len(set(currentQuestion))

    finalScore = (similarWordOrder + similarWords + similarLetters + wordsINTheWords) / 4

    return finalScore


QorR = input("Are you a Canidate or a Recruiter? [C/R]").lower().strip()
if not QorR:
    print("Invalid Answer! [C/R]")
elif QorR not in ['c', 'r']:
    print("Invalid Answer! [C/R]")
elif QorR == "c":
    qa = qaC
else:
    qa = qaR


threshold = 0.4
while True:
    question = input("What is your question?: ")

    question = question.lower().strip()

    if question == "exit":
        exit(6969420)

    scores = []
    for realQuestion in qa:
        scores.append((score(question, realQuestion), realQuestion))

    scores = sorted(scores, key=itemgetter(0))[::-1]
    
    bestScore = scores[0]

    if scores[0][0] == scores[1][0]:
        print("This question is not specific enough, please go into more detail.")
        continue

    elif bestScore[0] < threshold:
        print("This question is not in our database!")
        continue
    else:
        print(qa[bestScore[1]])




    
    